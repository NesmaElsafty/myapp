<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Helpers\PaginationHelper;
use App\Http\Resources\TermResource;
use App\Services\TermService;
use App\Models\Term;
use Exception;
use Illuminate\Http\Request;

class TermController extends Controller
{

    public function __construct(
        protected TermService $termService
    ) {}

    public function index(Request $request)
    {
        try {
            $request->validate([
                'search' => 'nullable|string|max:255',
                'type' => 'nullable|string|in:terms,privacy',
                'is_active' => 'nullable|boolean',
                'sorted_by' => 'nullable|string|in:newest,oldest,all,name',
            ]);

            $terms = $this->termService->getAll($request->all(), app()->getLocale())->paginate(10);

            return response()->json([
                'message' => __('messages.terms_retrieved_success'),
                'data' => TermResource::collection($terms),
                'pagination' => PaginationHelper::paginate($terms),
            ], 200);
        } catch (Exception $e) {
            return response()->json([
                'message' => __('messages.failed_retrieve_terms'),
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    /* "title_en": "Terms and Conditions",
    "title_ar": "الشروط والأحكام",
    "content_en": "These terms and conditions outline the rules and regulations for the use of our service.",
    "content_ar": "تحدد هذه الشروط والأحكام القواعد واللوائح لاستخدام خدمتنا.",
    "type": "terms", // can be "terms" or "privacy"
    "target_type": ["user", "admin"], // user,individual,origin,admin
    "is_active": true
    */
    public function store(Request $request)
    {
        try {
            $request->validate([
                'title_en' => 'required|string|max:255',
                'title_ar' => 'required|string|max:255',
                'content_en' => 'required|string',
                'content_ar' => 'required|string',
                'type' => 'required|string|in:terms,privacy',
                'target_type' => 'required|array|min:1|max:3',
                'target_type.*' => 'required|in:user,individual,origin',
            ]);

            $term = $this->termService->create($request->all());

            return response()->json([
                'message' => __('messages.term_created_success'),
                'data' => new TermResource($term),
            ], 201);
        } catch (Exception $e) {
            return response()->json([
                'message' => __('messages.failed_create_term'),
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function show(string $id)
    {
        try {
            $term = $this->termService->getById((int) $id);

            if (!$term) {
                return response()->json(['message' => __('messages.term_not_found')], 404);
            }

            return response()->json([
                'message' => __('messages.term_retrieved_success'),
                'data' => new TermResource($term),
            ], 200);
        } catch (Exception $e) {
            return response()->json([
                'message' => __('messages.failed_retrieve_term'),
                'error' => $e->getMessage(),
            ], 404);
        }
    }

    public function update(Request $request, string $id)
    {
        try {
            $request->validate([
                'title_en' => 'nullable|string|max:255',
                'title_ar' => 'nullable|string|max:255',
                'content_en' => 'nullable|string',
                'content_ar' => 'nullable|string',
                'type' => 'nullable|string|in:terms,privacy',
                'is_active' => 'nullable|boolean',
            ]);

            $term = $this->termService->update($id, $request->all());

            return response()->json([
                'message' => __('messages.term_updated_success'),
                'data' => new TermResource($term),
            ], 200);
        } catch (Exception $e) {
            return response()->json([
                'message' => __('messages.failed_update_term'),
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function destroy(string $id)
    {
        try {
            $this->termService->delete((int) $id);

            return response()->json([
                'message' => __('messages.term_deleted_success'),
            ], 200);
        } catch (Exception $e) {
            return response()->json([
                'message' => __('messages.failed_delete_term'),
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    // bulk actions
    public function bulkActions(Request $request)
    {
        try {
            $request->validate([
                'action' => 'required|in:toggleActive,delete,export',
                'term_ids' => 'nullable|array|exists:terms,id',
            ]);

            $term_ids = $request->term_ids;

            if(!$term_ids || count($term_ids) === 0) {
                $term_ids = Term::pluck('id')->toArray();
            }
            
            switch ($request->action) {
                case 'toggleActive':
                    $result = $this->termService->toggleActive($term_ids);
                    break;
                case 'delete':
                    $result = $this->termService->bulkDelete($term_ids);
                    break;
                case 'export':
                    $result = $this->termService->export($term_ids, app()->getLocale());
                    break;
            }

            return response()->json([
                'message' => __('messages.bulk_actions_success'),
                'data' => $result,
            ], 200);
        } catch (Exception $e) {
            return response()->json([
                'message' => __('messages.failed_bulk_actions'),
                'error' => $e->getMessage(),
            ], 500);
        }
    }
}

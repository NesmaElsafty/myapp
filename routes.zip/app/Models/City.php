<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class City extends Model
{
    protected $guarded = [];

    /**
     * Get the regions for the city.
     */
    public function regions(): HasMany
    {
        return $this->hasMany(Region::class);
    }

    public function items(): HasMany
    {
        return $this->hasMany(Item::class);
    }   
}

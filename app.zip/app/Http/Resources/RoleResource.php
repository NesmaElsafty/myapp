<?php

namespace App\Http\Resources;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class RoleResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        // get locale
        $locale = app()->getLocale();
        $name = $locale == 'ar' ? $this->name_ar : $this->name_en;
        $description = $locale == 'ar' ? $this->description_ar : $this->description_en;
        $total_admins = $this->users()->count();
        return [    
            'id' => $this->id,
            'name' => $name,
            'description' => $description,

            'name_en' => $this->name_en,
            'name_ar' => $this->name_ar,
            'description_en' => $this->description_en,
            'description_ar' => $this->description_ar,

            'permissions' => $this->whenLoaded('permissions', function () {
                return PermissionResource::collection($this->permissions);
            }),
            'total_admins' => $total_admins,
            'created_at' => $this->created_at,
        ];
    }
}
